os.setlocale ( 'C' )
