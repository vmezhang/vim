Preface
================================================================================

This repository is mainly for the use with plug-in managers.

The development happens here:
([WolfgangMehner/vim-plugins](https://github.com/WolfgangMehner/vim-plugins))


--------------------------------------------------------------------------------

