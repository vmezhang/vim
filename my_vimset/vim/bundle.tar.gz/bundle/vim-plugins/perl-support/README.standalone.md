Preface
================================================================================

This repository is mainly for the use with plug-in managers.

The development happens here:
([WolfgangMehner/vim-plugins](https://github.com/WolfgangMehner/vim-plugins))


Preview Version
================================================================================

___This is a preview version!___

This version is a preview, containing a reworked template engine.
Please report any problems.

The new features of Perl-Support and the template engine are:

- No need to edit stock templates anymore, by doing the personalization/
  customization in separate files
- Setup wizard for customization and personalization file
- More to come ...

_Please read the release notes below._


--------------------------------------------------------------------------------

